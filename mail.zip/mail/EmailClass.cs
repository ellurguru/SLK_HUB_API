﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Send_Email_WebApi.Models
{
    public class EmailClass
    {
        public string to { get; set; }
        public string subject { get; set; }
        public string body { get; set; }
    }
}