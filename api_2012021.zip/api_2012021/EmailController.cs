﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SLK_HUB_WEBAPI.Models;
using System.Net.Mail;
using System.IO;


namespace SLK_HUB_WEBAPI.Controllers
{
    public class EmailController : ApiController
    {
        [HttpPost]
        [ActionName("sendmail")]
        public IHttpActionResult processAuthEmail(SendMailRequest mailModel)
        {

            // Send the email
            System.Net.Mail.MailMessage msg = new MailMessage();

          


            // Include the file attachment if the filename is not null
            //if (mailModel.filename != null)
            //{
            //    // Declare a temp file path where we can assemble our file
            //    string tempPath = Configuration. Properties.Settings.Default["TempFile"].ToString();

            //    string filePath = Path.Combine(tempPath, mailModel.filename);

            //    using (System.IO.FileStream reader = System.IO.File.Create(filePath))
            //    {
            //        byte[] buffer = Convert.FromBase64String(mailModel.filecontent);
            //        reader.Write(buffer, 0, buffer.Length);
            //        reader.Dispose();
            //    }

            //    msg.Attachments.Add(new Attachment(filePath));

            //}
            using (SLKHUB_DBContext context = new SLKHUB_DBContext())
            {
                try
                {
                    var mailinfo = from email in context.EmailNotifications
                                select new
                                {
                                    ToEmail = email.ToEmail,
                                    CCEmail = email.CCEmail,
                                    Subject = email.Subject,
                                    Body = email.Body
                                   
                                };

                    foreach (var item in mailinfo)
                    {
                        // Separate the recipient array
                        string[] emailAddress = item.ToEmail.Split(',');

                        foreach (string currentEmailAddress in emailAddress)
                        {
                            msg.To.Add(new MailAddress(currentEmailAddress.Trim()));
                        }


                        // Separate the cc array , if not null
                        string[] ccAddress = null;

                        if (msg.CC != null)
                        {
                            ccAddress = item.CCEmail.Split(',');
                            foreach (string currentCCAddress in ccAddress)
                            {
                                msg.CC.Add(new MailAddress(currentCCAddress.Trim()));
                            }
                        }


                        // Include the reply to if not null
                        //if (mailModel.replyto != null)
                        //{
                        //    msg.ReplyToList.Add(new MailAddress(mailModel.replyto));
                        //}
                        
                        //item.Body.Replace("@uploadedon", mailModel.uploadedon);
                        //item.Body.Replace("@videoname", mailModel.videoname);
                        //item.Body.Replace("@category", mailModel.category);
                        msg.Body = item.Body.Replace("@uploadedby", mailModel.uploadby).Replace("@uploadedon", mailModel.uploadedon).Replace("@videoname", mailModel.videoname).Replace("@category", mailModel.category); ;
                        msg.Subject = item.Subject;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            string sendFromEmail = "gururaj.e@slkgroup.com";
            string sendFromName = "Gururaj E";
            string sendFromPassword = "Amma#2017";

            msg.From = new MailAddress(sendFromEmail, sendFromName);
            //msg.Subject = mailModel.subject;
            //msg.Body = mailModel.body;
         //   string textBody = "Dear Approver, <br /><br /> A video has been uploaded to SLK Hub by Gururaj E on 01/01/2021. " +
         //"<br /><br /> Kindly verify the uploaded video and approve the action. <br /><br /><table width=50%  border=1 cellspacing=0 cellpadding=0><tr><td align=left " + "valign=middle style=padding: 15px; font - family:Arial, Helvetica, sans - serif;>Video Name</td><td align=left " + "valign=middle style=padding: 15px; font - family:Arial, Helvetica, sans - serif;>The Future of Block chain</td></tr><tr><td align=left " + "valign=middle style=padding: 15px; font - family:Arial, Helvetica, sans - serif;>Category</td><td align=left " + "valign=middle style=padding: 15px; font - family:Arial, Helvetica, sans - serif;>Our Customers</td></tr></tr><tr><td align=left " + "valign=middle style=padding: 15px; font - family:Arial, Helvetica, sans - serif;>Current Status</td><td align=left " + "valign=middle style=padding: 15px; font - family:Arial, Helvetica, sans - serif;>Approval Pending</td></tr></table><br /><br />" + 
         //"Respectfully,<br />SLK Hub Admin Team";

         //   textBody += "</table>";
            
            msg.IsBodyHtml = true;


            SmtpClient client = new SmtpClient("smtp.office365.com");
            client.Port = 587;
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            NetworkCredential cred = new System.Net.NetworkCredential(sendFromEmail, sendFromPassword);
            client.Credentials = cred;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;




            try
            {
                client.Send(msg);
                msg.Dispose();

                // Clean up the temp directory if used
                if (mailModel.filename != null)
                {
                    //string tempPath = Properties.Settings.Default["TempFile"].ToString();
                    //string filePath = Path.Combine(tempPath, mailModel.filename);
                    //File.Delete(filePath);
                }

                return Ok("Mail Sent");
            }
            catch (Exception e)
            {
                return NotFound();
            }

        }
        //private string PopulateBody(string userName, string title, string url, string description)
        //{
        //    string body = string.Empty;
        //    using (StreamReader reader = new StreamReader(Configuration.MapPath("~/EmailTemplate.htm")))
        //    {
        //        body = reader.ReadToEnd();
        //    }
        //    body = body.Replace("{UserName}", userName);
        //    body = body.Replace("{Title}", title);
        //    body = body.Replace("{Url}", url);
        //    body = body.Replace("{Description}", description);
        //    return body;
        //}
    }
   
}
