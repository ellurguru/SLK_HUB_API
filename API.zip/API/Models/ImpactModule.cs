﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SLK_HUB_WEBAPI.Models
{
    public class ImpactModule
    {
        public string customer { get; set; }
        public string solution { get; set; }
        public string year { get; set; }
        public string slk_champion { get; set; }
        public string slug { get; set; }
        public string title { get; set; }
        public List<string> timeline { get; set; }
        public impdetail detail { get; set; }
        public List<impdocs> docs { get; set; }
        
        
    }

    public class impdetail
    {
        public string title { get; set; }
        public string type { get; set; }
        public string summary { get; set; }
        public List<string> keywords { get; set; }
    }

  

    public class impdocs
    {
        public string video { get; set; }
        public string title { get; set; }
        public string tag { get; set; }
    }
}

