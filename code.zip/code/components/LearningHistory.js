import {Col, Modal, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import React, {useState} from "react";

export default function LearningHistory({color, year, title, description, video_link, last}) {
  const [show_video_modal, setVideoModal] = useState(false)

  return (
    <>
      <Row className={'history'}>
        <Col className={'text-right text'}>
          <h6 className={'title'}>{title}</h6>
          <h6 className={'text-uppercase'}>
            {description.split('\n').map((item, key) => {
              return <span key={key}>{item}<br/></span>
            })}
          </h6>
        </Col>
        <Col xs={1}>
          <div className={'dots'}>
            <div>
              <div className={'circle'} style={{borderColor: color}}/>
            </div>
            {!last ? <div className={'line'}/> : null}
          </div>
        </Col>
        <Col>
          <div className={'d-flex'}>
            <h6 className={'title'}>{year}</h6>
            <Link to='#' onClick={() => setVideoModal(true)}>

            </Link>
          </div>
        </Col>
      </Row>
      <Modal
        size="md"
        className={'video_modal'}
        show={show_video_modal}
        onHide={() => console.log('closed')}
        backdrop="static">
        <div className={'close_button'} onClick={() => setVideoModal(false)}>

        </div>
        <div className={'video_wrap'}>
          <video id={'video_block'} src={video_link} controls
                 autoPlay/>
        </div>
        <div className={'video_links'}>
          <div className={'d-flex text-white'}>
            <p className={'m-0'}>{year}</p>
            <p className={'text-uppercase pl-3 m-0'}>
              {title}<br/>
              {description}
            </p>
          </div>
        </div>
      </Modal>
    </>
  )
}
