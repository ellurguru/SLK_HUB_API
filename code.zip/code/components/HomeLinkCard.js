import {Col, Image} from "react-bootstrap";
import React from "react";
import {Link} from "react-router-dom";

export default function HomeLinkCard({link, color, title, icon_url}) {
  return (
    <Col md={2} sm={6}>
      <div className="link-container-wrap">
        <Link to={link}>
          <div className={'artwork'}>
            <Image src={icon_url}/>
          </div>
          <div className={'link-container'} style={{backgroundColor: color}}>
            <h5>{title}</h5>
          </div>
        </Link>
      </div>
    </Col>
  )
}
