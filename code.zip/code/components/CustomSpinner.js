import {Spinner} from "react-bootstrap";
import React from "react";

export default function CustomSpinner({height}) {
  return (
    <div className={'d-flex justify-content-center align-items-center'}
         style={{height: height ? `${height}vh` : '30vh'}}>
      <Spinner animation="border"/>
    </div>
  )
}
