import {Breadcrumb, Container, Image} from "react-bootstrap";
import React from "react";

export default function BreadCrumb({icon_url, color, title, breadcrumb_data, Artwork}) {
  return (
    <section id={'bread-crumb'} style={{backgroundColor: color}}>
      <Container className={'py-3'}>
        <div className={'d-flex'}>
          <Image src={icon_url}/>
          <div className={'ml-2 mt-3'}>
            <h3>{title}</h3>
            <Breadcrumb>
              {breadcrumb_data.map((k, v) => <Breadcrumb.Item key={v.toString()} 
                                                              href={k.link}>{k.name}</Breadcrumb.Item>)}
            </Breadcrumb>
          </div>
        </div>
      </Container>
      <div className={'breadcrumb-artwork'}>
        <Artwork/>
      </div>
    </section>
  )
}
