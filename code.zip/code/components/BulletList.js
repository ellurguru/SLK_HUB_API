/*import {Col, Image, Row} from "react-bootstrap";
import RED_DOT from "../assets/red_dot.svg";
import React from "react";

export default function BulletList({list}) {
  return (
    <Row className={'bullet_list'}>
      {list.map((k, v) => (
        <ul className={'point'}>
        <Col key={v.toString()} xs={12}>
        <div className={'dots'}>
        <br/>
        {list.length !== v + 1 ? <div className={'line'}/> : null}
        </div>
        <li className={'point1'}>        
            <h5>{k}</h5>
          </li>
        </Col>
        </ul>
      ))}
    </Row>
  )
}*/
import {Col, Image, Row} from "react-bootstrap";
import RED_DOT from "../assets/red_dot.svg";
import React from "react";

export default function BulletList({list}) {
  return (
    <Row className={'bullet_list'}>
      {list.map((k, v) => (
        <Col key={v.toString()} xs={12}>
          <div className={'dots'}>
            <div className={'circle'}>
              <Image src={RED_DOT}/>
            </div>
            {list.length !== v + 1 ? <div className={'line'}/> : null}
          </div>
          <div className={'container-fluid'}>
            <h5>{k}</h5>
          </div>
        </Col>
      ))}
    </Row>
  )
}
