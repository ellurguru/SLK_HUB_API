import React, {useEffect, useState,useContext} from 'react'
import {
  Accordion,
  Button,
  Col,
  Dropdown,
  DropdownButton,
  Image,
  Row,
  Spinner,
  useAccordionToggle,
  AccordionContext
} from "react-bootstrap";
import {Link} from "react-router-dom";
import {ReactComponent as PlusCircle} from "../../assets/plus_circle.svg"
import {ReactComponent as MinusCircle} from "../../assets/minus_circle.svg"
import {AiFillMinusCircle, AiFillPlayCircle} from "react-icons/ai"
import EvolutionProgramDetail from "./EvolutionKeyProgramDetail";
import service from "../service/service.js";

function EvolutionKeyProgram() {
  const [active_tab, setActiveTab] = useState('first_tab')
  const [first_table_data, setFirstData] = useState([])
  const [first_table_page, setFirstPage] = useState(1)
  const [first_table_filter_by, setFirstFilter] = useState('')
  const [fetching, setFetching] = useState(true)
  const [show_program_slug, setProgramSlug] = useState('')
  const [show_impact_slug, setImpactSlug] = useState('')


  const fetch_first_table_data = (page = 1, filter_by = '') => {
    var results1=[];
    service.getImapcts("All")
    .then(res => {
       results1=res.data;
        console.log(results1);    
   setFetching(true)
   setFirstData(results1)
   setProgramSlug('')
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})
}

  // useEffect(() => {
  //   fetch_first_table_data()
  // }, [])

  useEffect(() => {
    fetch_first_table_data(first_table_page, first_table_filter_by)
  }, [first_table_page, first_table_filter_by, active_tab])


  const show_program_details = (program_slug,impact_id,customerid) => {
    localStorage.setItem('impact_id', impact_id);
    localStorage.setItem('customerid', customerid);
    setProgramSlug(program_slug)
  }

  // const CustomToggle = ({eventKey, title}) => {
  //   const decoratedOnClick = useAccordionToggle(eventKey, () => {
  //     if (show_program_slug.length > 0) {
  //       setProgramSlug('')
  //     }
  //   });

  const CustomToggle = ({eventKey, title,callback}) => {
    const currentEventKey = useContext(AccordionContext);
    const decoratedOnClick = useAccordionToggle(
      eventKey,
      () => callback && callback(eventKey),
    );
  
    const isCurrentEventKey = currentEventKey === eventKey;
    const decoratedOnClick1 = useAccordionToggle(eventKey, () => {
      
      debugger;
      //console.log(e);
  //alert(eventKey);
     
      if (show_impact_slug.length > 0) {
        setImpactSlug('')
      }
    });

    return (
      // <button onClick={decoratedOnClick} className="toggle_accordion">
      //   <h6>{title}</h6> <MinusCircle/>
      // </button>
      <button onClick={decoratedOnClick} className="toggle_accordion">
      <h6>{title}</h6>
      <div>
      {isCurrentEventKey == false ? <PlusCircle/> : <MinusCircle/>}
      </div>
      </button>
    );
  }

  const RenderFirstTableRow = ({item}) => (
    <Row className={`list_item ${item.slug}`}>
      <Col sm={12} md={2}>
        <div>
          <h6><Image src={item.customer} className="imgclass"/></h6>
        </div>
      </Col>
      <Col sm={12} md={2}>
        <h6><b style={{color:"black"}}>SOLUTION</b><br></br>{item.solution}</h6>
      </Col>
      <Col sm={12} md={2}>
        <h6><b style={{color:"black"}}>YEAR</b><br></br>{item.year}</h6>
      </Col>
      <Col sm={12} md={2}>
        <h6><b style={{color:"black"}}>SLK CHAMPION</b><br></br>{item.slk_champion}</h6>
      </Col>
      <Col sm={12} md={4} className={'has_accordion'}>
        
      <h6><b style={{color:"black"}}>DETAIL</b></h6>
        <Accordion>
          <CustomToggle eventKey="0" title={item.detail.title}/>
          
          <Accordion.Collapse eventKey="0">
            <div className={'d-flex pt-3 align-items-baseline justify-content-between'}>
              <div>
                <p className={'strong'}>
                  {item.detail.type}
                </p>
                {item.detail.keywords.map((m, n) => <p key={n.toString()}>{m}</p>)}
              </div>
              <Button variant={'link'} onClick={() => show_program_details(item.slug,item.Impact_id,item.customerid)} className={'play_link'}>
                <AiFillPlayCircle/>
              </Button>
            </div>
          </Accordion.Collapse>
        </Accordion>
      </Col>
    </Row>
  )

  return (
    <>
      {show_program_slug.length > 0 ?
        <EvolutionProgramDetail program_slug={show_program_slug} setProgramSlug={setProgramSlug}/> : (
          <>
            {fetching ? (
              <div className={'d-flex justify-content-center align-items-center'} style={{height: '30vh'}}>
                <Spinner animation="border"/>
              </div>
            ) : (
              <>
                <div className={'custom-list'}>
                  <Row className={'list_head'}>
                    {/* <Col sm={12} md={2}>
                      <h6>Customer</h6>
                    </Col>
                    <Col sm={12} md={2}>
                      <h6>Solution</h6>
                    </Col>
                    <Col sm={12} md={2}>
                      <h6>Year</h6>
                    </Col>
                    <Col sm={12} md={2}>
                      <h6>SLK Champion</h6>
                    </Col> */}
                    <Col sm={12} md={4}>
                      {/* <h6>Detail</h6> */}
                      <DropdownButton
                        size="sm"
                        menuAlign="right"
                        title="SORT BY"
                        id="sort_by"
                      >
                        <Dropdown.Item eventKey="3"
                                       onClick={() => setFirstFilter('customer')}>Customer</Dropdown.Item>
                        <Dropdown.Item eventKey="1"
                                       onClick={() => setFirstFilter('year')}>Year</Dropdown.Item>
                        <Dropdown.Item eventKey="2"
                                       onClick={() => setFirstFilter('slk_champion')}>
                          SLK Champion
                        </Dropdown.Item>
                      </DropdownButton>
                    </Col>
                  </Row>
                  {first_table_data.map((k, v) => <RenderFirstTableRow key={v.toString()} item={k}/>)}
                </div>
                <div className={'pages'}>
                  <Link to='#' onClick={() => setFirstPage(1)}
                        className={first_table_page === 1 ? 'active' : ''}>1</Link>
                  {/* <Link to='#' onClick={() => setFirstPage(2)}
                        className={first_table_page === 2 ? 'active' : ''}>2</Link>
                  <Link to='#' onClick={() => setFirstPage(3)}
                        className={first_table_page === 3 ? 'active' : ''}>3</Link> */}
                </div>
              </>
            )}
          </>
        )}
    </>
  )
}

export default EvolutionKeyProgram
