import React, {useEffect, useState} from 'react';
import CustomSpinner from "../../components/CustomSpinner";
import FocusHistory from "../../components/FocusHistory";
import {Col, Row} from "react-bootstrap";
import service from "../service/service.js";

function EvolutionFocus() {
  const [fetching, setFetching] = useState(false)
  const [data, setData] = useState([])
  const color_codes = ['#F20F87', '#69b6d5', '#F9D05E', '#FF4DD5', '#4E99DB', '#4E99DB', '#EF4343', '#A074F1']

  /*const sample_response = {
    results: [
      {
        title: 'Establish SLK\n Delivery Engine\n Acquire First Customer',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Scale Across Customers\n Large Programs \n CMM Certification',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Scale Across Customers\n Large Programs \n CMM Certification',
        year: '2010',
        video: SampleVideo2
      },

      {
        title: 'Scale Across Customers\n Large Programs \n CMM Certification',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Scale Across Customers\n Large Programs \n CMM Certification',
        year: '2010',
        video: SampleVideo2
      },

    ]
  }
*/
  const fetch_learning_data = () => {
     var results=[];
     service.getevolfocusdetails()
     .then(res => {
        results=res.data;
         console.log("focus",results);    
    setFetching(true)
    setData(results)
    setTimeout(() => {
      setFetching(false)
    }, 1000)
 })

  }

  useEffect(() => {
    fetch_learning_data()
  }, [])


  return (
    <>
      {fetching ? <CustomSpinner/> : (
        <Row className={'justify-content-center'}>
          <Col xs={12} sm={6}>
            {data.map((k, v) => {
              let color = color_codes[v >= 8 ? (v % 8) : v];
              return <FocusHistory key={v.toString()}
                                   last={data.length === v + 1}
                                   first={v === 0}
                                   color={color}
                                   year={k.Year} title={k.Description}
                                   description={k.description}
                                   video_link={k.Doc_Path}/>
            })}
          </Col>
        </Row>
      )}
    </>
  )
}

export default EvolutionFocus
