import React, {useState} from 'react'
import evolution from '../../assets/evolution.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/evolution_artwork.svg"
import {Container} from "react-bootstrap";
import {Link} from "react-router-dom";
import EvolutionOffice from "./EvolutionOffice";
import EvolutionFocus from "./EvolutionFocus";
import EvolutionKeyProgram from "./EvolutionKeyProgram";

function Evolution() {
  const [active_tab, setActiveTab] = useState('offices')

  const [breadcrumb_data, setBreadcrumbData] = useState([
    {
      'link': '/slk-hub/',
      'name': 'Home'
    },
    {
      'link': '/slk-hub/evolution/',
      'name': 'Our Evolution'
    },
    {
      'link': '#',
      'name': 'Offices'
    }
  ])

  const toggle_tab = (tab) => {
    let tab_name = ''
    if (tab === 'offices') {
      tab_name = 'Offices'
    }
    if (tab === 'programs') {
      tab_name = 'Key Programs'
    }
    if (tab === 'focus') {
      tab_name = 'Strategic Focus'
    }
    setActiveTab(tab)
    setBreadcrumbData([
      {
        'link': '/slk-hub/',
        'name': 'Home'
      },
      {
        'link': '/slk-hub/evolution/',
        'name': 'Our Evolution'
      },
      {
        'link': '#',
        'name': tab_name
      }
    ])
  }

  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#FF824F"
                  icon_url={evolution}
                  title="Our Evolution"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={`evolution ${active_tab === 'programs' ? 'artwork' : ''}`}>
        <Container>
          <div className={'tabs'}>
            <div className={'tab-content'}>
              <Link to="#" className={active_tab === 'offices' ? 'active' : ''}
                    onClick={() => toggle_tab('offices')}>
                Offices
              </Link>
              <Link to="/customers/">
                Customers
              </Link>
              <Link to="#" className={active_tab === 'programs' ? 'active' : ''}
                    onClick={() => toggle_tab('programs')}>
                Key Programs
              </Link>
              <Link to="#" className={active_tab === 'focus' ? 'active' : ''}
                    onClick={() => toggle_tab('focus')}>
                Strategic Focus
              </Link>
            </div>
          </div>
          <div className={'tab-content-wrap'}>
            {active_tab === 'offices' ? <EvolutionOffice/> : null}
            {active_tab === 'programs' ? <EvolutionKeyProgram/> : null}
            {active_tab === 'focus' ? <EvolutionFocus/> : null}
          </div>
        </Container>
      </section>
    </main>
  )
}

export default Evolution
