import http from "./http-common";

class Service {
 getcustdetails() {
  return http.get('/api/GetCustomers');
  }
  getcustdetailsbyid(CustomerName) {
    return http.get('/api/GetCustomersData/'+ CustomerName);
    }
  getemployeejourney() {
      return http.get('/api/GetEmployeeJourney');
    }
  getImapcts(ImpactType) {
      return http.get('/api/GetImpactData/'+ImpactType);
  }
  getImapctdetailsbyid(impactid,customerid) {
    return http.get('/api/GetImpactDetailsById/'+impactid+'/'+customerid);
}
getGetExternalExperience() {
  return http.get('/api/GetExternalExperience');
}
getCareerGrowth() {
  return http.get('/api/GetCareerGrowth');
}

getlearningdetails() {
  return http.get('/api/GetLearnings');
  }
 getevolofficedetails() {
  return http.get('/api/GetEvolutionDocuments');
  }
 getevolfocusdetails() {
  return http.get('/api/GetEvolutionStrategicFocus');
  }
  getethosbeliefdetails(){
  return http.get('/api/GetEthosDocumentsLevel1/Item level 1');
  }
   getethosvaluesdetails(){
  return http.get('/api/GetEthosDocumentsLevel2/Item level 2');
  }
  getethoscultureInnovationdetails(){
  return http.get('/api/GetEthosCulture_Innovation/Innovation');
  }
  getethoscultureUniquedetails(){
  return http.get('/api/GetEthosCulture_Unique/Unique');
  }
  getethoscultureFundetails(){
  return http.get('/api/GetEthosCulture_Fun/Fun');
  }
}
const ser = new Service();
export default ser;

