import axios from "axios";

export default axios.create({
 baseURL:"https://localhost:44321",
 //baseURL:"https://121.244.210.244:8443/slk_hub_webapi",
 //baseURL:"https://converge.slk-soft.com/slk_hub_webapi",
 //baseURL:"https://converge/slk_hub_webapi",
  headers: {
    "Content-type": "application/json"
  }
});