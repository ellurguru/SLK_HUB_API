import React, {useEffect, useState} from 'react'
import people from '../../assets/people.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/people-artwork.svg"
import {Container, Spinner} from "react-bootstrap";
import {ReactComponent as CollegeSVG} from "../../assets/carrier.svg"
import {Link} from "react-router-dom";
import 'react-multi-carousel/lib/styles.css';
import CollegeHistory from "../../components/CollegeHistory";
import service from "../service/service.js";

function Careergrowth() {
  const breadcrumb_data = [
    {
      'link': '/slk-hub/',
      'name': 'Home'
    },
    {
      'link': '/slk-hub/people/',
      'name': 'Our People'
    },
    {
      'link': '/slk-hub/people/careergrowth/',
      'name': 'Career Growth'
    }
  ]
  // const sampleResponse1 = {
  //   page: 1,
  //   results: [
  //     {
  //       name: 'Maya Shenoy',
  //       image: TEMP_IMAGE_3,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',
  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         }
  //       ]
  //     },
  //     {
  //       name: 'Harsha Maddula',
  //       image: TEMP_IMAGE_1,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',
  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         }
  //       ]
  //     },
  //     {
  //       name: 'Armaan Suhail',
  //       image: TEMP_IMAGE_2,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',

  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //       ]
  //     }
  //   ]
  // }
  // const sampleResponse2 = {
  //   page: 2,
  //   results: [
  //     {
  //       name: 'Maya Shenoy',
  //       image: TEMP_IMAGE_3,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',
  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         }
  //       ]
  //     },
  //     {
  //       name: 'Harsha Maddula',
  //       image: TEMP_IMAGE_1,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',
  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         }
  //       ]
  //     },
  //     {
  //       name: 'Armaan Suhail',
  //       image: TEMP_IMAGE_2,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',

  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //       ]
  //     }
  //   ]
  // }
  // const sampleResponse3 = {
  //   page: 3,
  //   results: [
  //     {
  //       name: 'Maya Shenoy',
  //       image: TEMP_IMAGE_3,
  //       video_link: SAMPLE_VIDEO,
  //       video_description: 'Nunc interdum lacus sit amet orci. Pellentesque commodo eros a enim. Nullam quis ante. Ut leo. Nullam cursus lacinia erat. Etiam ut purus mattis mauris sodales aliquam. Morbi ac felis. Aenean viverra rhoncus pede. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Fusce convallis metus id felis luctus adipiscing.',
  //       records: [
  //         {
  //           highlight: true,
  //           star: false,
  //           title: 'Fresher from JCE, Mysore',
  //           year: '2001',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Lead – BPM Practice ',
  //           year: '2005',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'CBU Head',
  //           year: '2010',
  //         },
  //         {
  //           highlight: false,
  //           star: false,
  //           title: 'Head – Industry Solutions',
  //           year: '2016',
  //         },
  //         {
  //           highlight: true,
  //           star: true,
  //           title: 'VP & Head Strategic Programs',
  //           year: '2020',
  //         }
  //       ]
  //     }
  //   ]
  // }

  const [page, setPageNo] = useState(1)
  const [data, setData] = useState([])
  const [fetching, setFetching] = useState(true)

  // const fetch_data = (page) => {
  //   if (page === 1) {
  //     setData(sampleResponse1.results)
  //     setTimeout(() => {
  //       setFetching(false)
  //     }, 2000)
  //   }
  //   // if (page === 2) {
  //   //   setData(sampleResponse2.results)
  //   //   setTimeout(() => {
  //   //     setFetching(false)
  //   //   }, 2000)
  //   // }
  //   // if (page === 3) {
  //   //   setData(sampleResponse3.results)
  //   //   setTimeout(() => {
  //   //     setFetching(false)
  //   //   }, 2000)
  //   // }
  // }

  const fetch_data = (page) => {
    var results=[];
    service.getCareerGrowth()
    .then(res => {
       results=res.data;
        console.log(results);    
   setFetching(true)
   setData(results)
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})

 }

  useEffect(() => {
    setFetching(true)
    fetch_data(page)
  }, [page])

  useEffect(() => {
    setPageNo(1)
  }, [])


  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#01C6D9"
                  icon_url={people}
                  title="Our People"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'peoples'}>
        <Container>
          <section id={'heading'}>
            <CollegeSVG/>
            <Link to="#">Intranet Page Link</Link>
          </section>
          <section id={'people-container'}>
            <div id="colleges">
              {!fetching ? (
                <>
                  {data.map((k, v) => <CollegeHistory
                    key={v.toString()}
                    last={v === data.length - 1}
                    image_url={k.image}
                    name={k.name}
                    video_link={k.video_link}
                    video_description={k.video_description}
                    records={k.records}/>)}
                </>
              ) : (
                <div className={'d-flex justify-content-center align-items-center'} style={{height: '30vh'}}>
                  <Spinner animation="border"/>
                </div>
              )}
              {/* <div className={'pages'}>
                <Link to='#' onClick={() => setPageNo(1)} className={page === 1 ? 'active' : ''}>1</Link> 
                <Link to='#' onClick={() => setPageNo(2)} className={page === 2 ? 'active' : ''}>2</Link>
                <Link to='#' onClick={() => setPageNo(3)} className={page === 3 ? 'active' : ''}>3</Link>
              </div>
              <div className={'text-center w-100 mt-5'}>
                <Link to="#" className={'text-center text-dark'}><i>Intranet Page Link</i></Link>
              </div> */}
            </div>
          </section>
        </Container>
      </section>
    </main>
  )
}

export default Careergrowth
