import React, {useEffect, useState} from 'react'
import people from '../../assets/people.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/people-artwork.svg"
import {Container, Spinner} from "react-bootstrap";
import {ReactComponent as CollegeSVG} from "../../assets/external.svg"
import {Link} from "react-router-dom";
import 'react-multi-carousel/lib/styles.css';
import CollegeHistory from "../../components/CollegeHistory";
import service from "../service/service.js";

function Externalexperience() {
  const breadcrumb_data = [
    {
      'link': '/slk-hub/',
      'name': 'Home'
    },
    {
      'link': '/slk-hub/people/',
      'name': 'Our People'
    },
    {
      'link': '/slk-hub/people/externalexperience/',
      'name': 'External Experience'
    }
  ]
  

  const [page, setPageNo] = useState(1)
  const [data, setData] = useState([])
  const [fetching, setFetching] = useState(true)
  const fetch_data = (page) => {
    var results=[];
    service.getGetExternalExperience()
    .then(res => {
       results=res.data;
        console.log(results);    
   setFetching(true)
   setData(results)
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})

 }

  useEffect(() => {
    setFetching(true)
    fetch_data(page)
  }, [page])

  useEffect(() => {
    setPageNo(1)
  }, [])


  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#01C6D9"
                  icon_url={people}
                  title="Our People"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'peoples'}>
        <Container>
          <section id={'heading'}>
            <CollegeSVG/>
            {/* <Link to="#">Intranet Page Link</Link> */}
          </section>
          <section id={'people-container'}>
            <div id="colleges">
              {!fetching ? (
                <>
                  {data.map((k, v) => <CollegeHistory
                    key={v.toString()}
                    last={v === data.length - 1}
                    image_url={k.image}
                    name={k.name}
                    video_link={k.video_link}
                    video_description={k.video_description}
                    records={k.records}/>)}
                </>
              ) : (
                <div className={'d-flex justify-content-center align-items-center'} style={{height: '30vh'}}>
                  <Spinner animation="border"/>
                </div>
              )}
              {/* <div className={'pages'}>
                <Link to='#' onClick={() => setPageNo(1)} className={page === 1 ? 'active' : ''}>1</Link>
                <Link to='#' onClick={() => setPageNo(2)} className={page === 2 ? 'active' : ''}>2</Link>
                <Link to='#' onClick={() => setPageNo(3)} className={page === 3 ? 'active' : ''}>3</Link>
              </div>
              <div className={'text-center w-100 mt-5'}>
                <Link to="#" className={'text-center text-dark'}><i>Intranet Page Link</i></Link>
              </div> */}
            </div>
          </section>
        </Container>
      </section>
    </main>
  )
}

export default Externalexperience
