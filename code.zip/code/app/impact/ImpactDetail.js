import React, {useEffect, useState} from 'react'
import {Button, Col, Image, Row, Spinner} from "react-bootstrap";
import BulletList from "../../components/BulletList";
import {ReactComponent as MinusCircle} from "../../assets/minus_circle.svg";
import service from "../service/service.js";

function ImpactDetail({impact_slug, setBreadcrumb, setImpactSlug}) {
  const [impact_detail, setData] = useState({})
  const [fetching, setFetching] = useState(true)
  const fetch_detail_data = (impact_slug) => {
    var results;
    var customerid=parseInt(localStorage.getItem('customerid'));
    var impact_id=parseInt(localStorage.getItem('impact_id'));
    // alert(customerid);
    // alert(impact_id);
    service.getImapctdetailsbyid(customerid,impact_id)
    .then(res => {
       results=res.data;
        console.log(results);    
   setFetching(true)
   setData(results)
   setBreadcrumb([
    {
      'link': '/slk-hub/',
      'name': 'Home'
    },
    {
      'link': '/slk-hub/impact/',
      'name': 'Our Impact'
    },
    {
      'link': `/slk-hub/impact/${impact_slug}/`,
      'name': results.title
    }
  ])
   setTimeout(() => {
     setFetching(false)
   }, 1000)
})

 }
  // const fetch_detail_data = (impact_slug) => {
  
  //   setFetching(true);
  //   setData(sample_detail_response);
  //   setBreadcrumb([
  //     {
  //       'link': '/',
  //       'name': 'Home'
  //     },
  //     {
  //       'link': '/impact/',
  //       'name': 'Our Impact'
  //     },
  //     {
  //       'link': `/impact/${impact_slug}/`,
  //       'name': sample_detail_response.title
  //     }
  //   ])
  //   setTimeout(() => {
  //     setFetching(false)
  //   }, 1000);
  // }

  useEffect(() => {
    fetch_detail_data(impact_slug)
  }, [])

  return (
    <div id={'impact-detail-container'}>
      {fetching ? (
        <div className={'d-flex justify-content-center align-items-center'} style={{height: '30vh'}}>
          <Spinner animation="border"/>
        </div>
      ) : (
        <div className={'row_detail'}>
          <div className={'custom-list'}>
            <Row className={'list_item'}>
              <Col sm={12} md={2}>
                <div>
                  <Image src={impact_detail.customer} className="imgclass"/>
                </div>
              </Col>
              <Col sm={12} md={2}>
                <h6><b style={{color:"black"}}>SOLUTION</b><br></br>{impact_detail.solution}</h6>
              </Col>
              <Col sm={12} md={2}>
                <h6><b style={{color:"black"}}>YEAR</b><br></br>{impact_detail.year}</h6>
              </Col>
              <Col sm={12} md={2}>
                <h6><b style={{color:"black"}}>SLK CHAMPION</b><br></br>{impact_detail.slk_champion}</h6>
              </Col>
              <Col sm={12} md={4} className={'has_accordiondetails'}>
                <div className={'d-flex pt-3 align-items-baseline justify-content-between'}>
                  <div>
                    <h6 className={'mb-3'}><b style={{color:"black"}}>DETAIL</b><br></br>{impact_detail.detail.title}</h6>
                    <p className={'strong'}>
                      {impact_detail.detail.type}
                    </p>
                    {impact_detail.detail.keywords.map((m, n) => <p key={n.toString()}>{m}</p>)}
                  </div>
                  <Button variant={'link'} onClick={() => {
                    setImpactSlug('');
                    setBreadcrumb([
                      {
                        'link': '/',
                        'name': 'Home'
                      },
                      {
                        'link': '/impact/',
                        'name': 'Our Impact'
                      }
                    ])
                  }} className={'pause_link'}>
                    <MinusCircle/>
                  </Button>
                </div>
              </Col>
            </Row>
          </div>
          <div className={'impact_content row'}>
            <Row className={'align-items-center'}>
              <Col sm={6} xs={12}>
              <h6>{impact_detail.docs.length>0 ? impact_detail.docs[0].title : ""}</h6>
                <video src={impact_detail.docs.length>0 ? impact_detail.docs[0].video : null} controls/>
                              
              </Col>
              <Col sm={6} xs={12}>
                <BulletList list={impact_detail.timeline}/>
              </Col>
            </Row>
          
          <div className={'row_videos'}>
            <Row>
              {impact_detail.docs.map((k, v) => (
                <Col key={v.toString()} sm={4} className={'mb-3'}>
                   <h6>
                    {k.title}
                  </h6>
                  <div className={'video_wrap'}>
                    <video src={k.video} controls/>
                    {k.tag.length > 0 ? (
                      <div className={'tag'}>
                        <span>{k.tag}</span>
                      </div>
                    ) : null}
                  </div>
                 
                </Col>
              ))}
            </Row>
          </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ImpactDetail
