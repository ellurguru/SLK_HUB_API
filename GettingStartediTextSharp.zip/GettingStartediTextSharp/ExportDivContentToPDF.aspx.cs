﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Data.SqlClient;
using System.Configuration;

public partial class ExportDivContentToPDF : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConString = ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(ConString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT TOP 1 EmployeeID, LastName, FirstName, Title, BirthDate, City, Region, PostalCode, Country FROM Employees";
            cmd.Connection = con;
            con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            if (dt.Rows.Count > 0)
            {                
                //Bind Datatable to Labels
                lblEmployeeId.Text = dt.Rows[0]["EmployeeID"].ToString();
                lblFirstName.Text = dt.Rows[0]["FirstName"].ToString();
                lblLastName.Text = dt.Rows[0]["LastName"].ToString();
                lblCity.Text = dt.Rows[0]["City"].ToString();
                lblState.Text = dt.Rows[0]["Region"].ToString();
                lblPostalCode.Text = dt.Rows[0]["PostalCode"].ToString();
                lblCountry.Text = dt.Rows[0]["Country"].ToString();
            }
            con.Close();           
        }
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Employee.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        
        StringWriter stringWriter = new StringWriter();
        HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);
        employeelistDiv.RenderControl(htmlTextWriter);
        
        StringReader stringReader = new StringReader(stringWriter.ToString());
        Document Doc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(Doc);
        PdfWriter.GetInstance(Doc, Response.OutputStream);
        
        Doc.Open();
        htmlparser.Parse(stringReader);
        Doc.Close();
        Response.Write(Doc);
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }  
}