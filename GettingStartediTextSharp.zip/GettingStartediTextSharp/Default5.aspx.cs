﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using System.IO;
using System.Collections;
using System.Net;
using System.Collections.Generic;
using iTextSharp.text.html.simpleparser;

public partial class Default5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        HtmlForm form = new HtmlForm();
        form.Controls.Add(gvEmployees);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hTextWriter = new HtmlTextWriter(sw);
        form.Controls[0].RenderControl(hTextWriter);
        string html = sw.ToString();
        Document Doc = new Document();      
        PdfWriter.GetInstance(Doc, new FileStream(Environment.GetFolderPath
        (Environment.SpecialFolder.Desktop) + "\\EmployeeList.pdf", FileMode.Create));
        Doc.Open();       
        System.Xml.XmlTextReader xmlReader =
        new System.Xml.XmlTextReader(new StringReader(html));      
        using (TextReader sReader = new StringReader(html.ToString()))
        {
            List<IElement> list = HTMLWorker.ParseToList(sReader, new StyleSheet());
            foreach (IElement elm in list)
            {
                Doc.Add(elm);
            }
        }
        Doc.Close();
        string Path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\EmployeeList.pdf";
        ShowPdf(Path);
    }

    private void ShowPdf(string strS)
    {
        Response.ClearContent();
        Response.ClearHeaders();
        Response.ContentType = "application/pdf";
        Response.AddHeader("Content-Disposition", "attachment; filename=" + strS);
        Response.TransmitFile(strS);
        Response.End();
        //Response.WriteFile(strS);
        Response.Flush();
        Response.Clear();

    }
}