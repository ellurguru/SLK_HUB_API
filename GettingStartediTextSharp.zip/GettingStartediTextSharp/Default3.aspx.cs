﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using System.IO;
using System.Text.RegularExpressions;
using System.Drawing;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=EmployeeList.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        
        StringWriter stringWriter = new StringWriter();
        HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);        
        
        gvEmployees.DataBind();
        gvEmployees.RenderControl(htmlTextWriter);
        gvEmployees.HeaderRow.Style.Add("width", "10%");
        gvEmployees.HeaderRow.Style.Add("font-size", "15px");
        gvEmployees.Style.Add("text-decoration", "none");
        gvEmployees.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
        gvEmployees.Style.Add("font-size", "8px");
       
        StringReader sr = new StringReader(stringWriter.ToString());
        
        Document doc = new Document(PageSize.A2, 7f, 7f, 7f, 0f);
        
        HTMLWorker htmlparser = new HTMLWorker(doc);
        
        PdfWriter.GetInstance(doc, Response.OutputStream);
        
        doc.Open();
        htmlparser.Parse(sr);
        doc.Close();
        Response.Write(doc);
        Response.End();      
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }    
}