﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using System.IO;
using System.Text.RegularExpressions;


public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCreatePDF_Click(object sender, EventArgs e)
    {
        Document doc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        string pdfFilePath = Server.MapPath(".") + "/PDFFiles";       
        PdfWriter writer = PdfAWriter.GetInstance(doc, new FileStream(pdfFilePath + "/Default.pdf", FileMode.Create));
        doc.Open();
        try
        {
            Paragraph paragraph = new Paragraph("Getting Started ITextSharp.");
            string imageURL = Server.MapPath(".") + "/image2.jpg";
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageURL);
            //Resize image depend upon your need
            jpg.ScaleToFit(140f, 120f);
            //Give space before image
            jpg.SpacingBefore = 10f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.ALIGN_LEFT;

            doc.Add(paragraph);
            doc.Add(jpg);

        }
        catch (Exception ex)
        { }
        finally
        {
            doc.Close();
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
}