﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using System.IO;
using System.Text.RegularExpressions;
using System.Drawing;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        PdfPTable table = new PdfPTable(gvEmployees.Columns.Count);
        int[] widths = new int[gvEmployees.Columns.Count];
        for (int x = 0; x < gvEmployees.Columns.Count; x++)
        {
            widths[x] = (int)gvEmployees.Columns[x].ItemStyle.Width.Value;
            string cellText = Server.HtmlDecode(gvEmployees.HeaderRow.Cells[x].Text);
            PdfPCell cell = new PdfPCell(new Phrase(cellText));
            //cell.BackgroundColor = BaseColor.GRAY;
            table.AddCell(cell);
        }
        table.SetWidths(widths);

        //Transfer rows from GridView to table
        for (int i = 0; i < gvEmployees.Rows.Count; i++)
        {
            if (gvEmployees.Rows[i].RowType == DataControlRowType.DataRow)
            {
                for (int j = 0; j < gvEmployees.Columns.Count; j++)
                {
                    string cellText = Server.HtmlDecode
                                      (gvEmployees.Rows[i].Cells[j].Text);
                    PdfPCell cell = new PdfPCell(new Phrase(cellText));
                    //Set Color of Alternating row
                    //if (i % 2 != 0)
                    //{
                    //    cell.BackgroundColor = BaseColor.BLUE;
                    //}
                    table.AddCell(cell);
                }
            }
        }

        //Create the PDF Document
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        pdfDoc.Add(table);
        pdfDoc.Close();
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;" +
                                       "filename=EmployeeList.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Write(pdfDoc);
        Response.End();        
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
    }   
}