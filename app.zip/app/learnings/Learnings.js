import React, {useEffect, useState} from 'react'
import learning from '../../assets/learnings.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/learning-artwork.svg"
import {Col, Container, Row} from "react-bootstrap";
import LearningHistory from "../../components/LearningHistory";
import CustomSpinner from "../../components/CustomSpinner";
import service from "../service/service.js";

function Learnings() {
  const [fetching, setFetching] = useState(false)
  const [data, setData] = useState([])
  const color_codes = ['#F20F87', '#69b6d5', '#F9D05E', '#FF4DD5', '#4E99DB', '#4E99DB', '#EF4343', '#A074F1']

  const breadcrumb_data = [
    {
      'link': '/',
      'name': 'Home'
    },
    {
      'link': '/learnings/',
      'name': 'Our Learnings'
    }
  ]

  /*const sample_response = {
    results: [
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      },
      {
        title: 'Big Block',
        description: 'An acquisition by SLK of a niche Digital Creative Experience Company Based on CA, USA',
        year: '2010',
        video: SampleVideo2
      }
    ]
  }*/

 const fetch_learning_data = () => {
     var results=[];
     service.getlearningdetails()
     .then(res => {
        results=res.data;
         console.log("Learnings",results);    
    setFetching(true)
    setData(results)
    setTimeout(() => {
      setFetching(false)
    }, 1000)
 })

  }
  useEffect(() => {
    fetch_learning_data()
  }, [])


  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#4E99DB"
                  icon_url={learning}
                  title="Our Learnings"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'learnings'}>
        <Container>
          <Row className={'justify-content-center'}>
            <Col xs={12} sm={6}>
              {fetching ? <CustomSpinner/> : (
                <>
                  {data.map((k, v) => {
                    let color = color_codes[v >= 8 ? (v % 8) : v];
                    return <LearningHistory key={v.toString()}
                                            last={data.length === v + 1}
                                            color={color}
                                            year={k.Year} title={k.Name}
                                            video_link={k.Doc_Path}
                                            description={k.Description}/>
                                            
                  })}
                </>
              )}
            </Col>
          </Row>
        </Container>
      </section>
    </main>
  )
}

export default Learnings
