import React, {useEffect,useState} from 'react'
import ethos from '../../assets/ethos.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/ethos_artwork.svg"
import {Container, Modal} from "react-bootstrap";
import {Link} from "react-router-dom";
import SampleVideo1 from "../../assets/sample_video.mp4";
import SampleVideo2 from "../../assets/sample2.mp4";
import service from "../service/service.js";


function EthosCulture() {
  const [fetching, setFetching] = useState(false)
var path=[];
var name=[];
  const [innovation_video_url, setData1] = useState()
  const [unique_video_url, setData2] = useState([])
  const [fun_video_url, setData3] = useState([])

  const [show_innovation_modal, setInnovationModal] = useState(false)
  const [data1, set_innovation_modal] = useState([])

  const [show_unique_modal, setUniqueModal] = useState(false)
 const [data2, set_unique_modal] = useState([])

  const [show_fun_modal, setFunModal] = useState(false)
  const [data3, set_fun_modal] = useState([])
  //const [data, setData] = useState([])

  const breadcrumb_data = [
    {
      'link': '/',
      'name': 'Home'
    },
    {
      'link': '/ethos/',
      'name': 'Our Ethos'
    },
    {
      'link': '/ethos/culture/',
      'name': 'Culture'
    }
  ]


  const fetch_learning_data1 = () => {
        var results=[];
      var results1=[];
      service.getethoscultureInnovationdetails()
  .then(res => {
    results=res.data;
    results1=res.data;
    setData1(results1[0].Doc_Path)
    console.log("dsfa1",results);    
    set_innovation_modal(results)
    setFetching(true)
    setTimeout(() => {
    setFetching(false)
    }, 1)
 })
  }
const fetch_learning_data2 = () => {
  var results=[];
      var results1=[];
service.getethoscultureUniquedetails()
     .then(res => {
    results=res.data;
    results1=res.data;
    setData2(results1[0].Doc_Path)
    console.log("dsfa2",results);    
    setFetching(true)
    set_unique_modal(results)
    setTimeout(() => {
    setFetching(false)
    }, 1)
 })
}
const fetch_learning_data3 = () => {
  var results=[];
  var p=[];
      var results1=[];
      service.getethoscultureFundetails()
     .then(res => {
    results=res.data;

console.log("jk",path)
    results1=res.data;
    setData3(results1[0].Doc_Path)

    console.log("dsfa3",results);    
    setFetching(true)
    set_fun_modal(results)
    setTimeout(() => {
    setFetching(false)
    }, 1)
 })



}


  useEffect(() => {
  fetch_learning_data1()

  fetch_learning_data2()
  
  fetch_learning_data3()
  },[])


  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#D3DF4D"
                  icon_url={ethos}
                  title="Our Ethos"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'ethos'}>
        <Container>

        <section id={'ethos-links'}>
            <div className={'d-flex'}>
              <Link to='/ethos/belief-philosophy/' id="ethos-belief">
                <div className={'link'}/>
              </Link>
              <Link to='/ethos/values/' id="ethos-values">
                <div className={'link'}/>
              </Link>
              <Link to='/ethos/culture/' id="ethos-culture">
                <div className={'link active'}/>
              </Link>
            </div>
          </section>
          <div className={'wave'}/>
          <section id={'ethos-container'} className={'artwork'}>
            <div id="culture">
              <Link to="#" id="innovation" onClick={() => setInnovationModal(true)}>
                <div className={'link'}/>
              </Link>
              <Modal

                size="md"
                className={'video_modal'}
                show={show_innovation_modal}
                onHide={() => console.log('closed')}
                backdrop="static">
                <div className={'close_button'} onClick={() => setInnovationModal(false)}>
                </div>
                    <div  className={'video_wrap'}>
                    <video id={'video_block'} src={innovation_video_url} controls autoPlay/>
                    </div>
                    <div className={'video_links'}>
                    <ul>
              
                    {data1.map((k,v) => (
                      
                    <li key={v}>
                   
                    <div className={'video-container'}>
                    <Link to="#" onClick={() => setData1('{k.Doc_Path}')}>  
                    {k.Name}
                    </Link>
                    </div>
                    </li>
                    ))}
                    
            </ul>
           </div>
              </Modal>
              <Link to="#" id="unique" onClick={() => setUniqueModal(true)}>
                <div className={'link'}/>
              </Link>
              <Modal
                size="md"
                className={'video_modal'}
                show={show_unique_modal}
                onHide={() => console.log('closed')}
                backdrop="static">
                <div className={'close_button'} onClick={() => setUniqueModal(false)}>

                </div>
                 <div  className={'video_wrap'}>
                    <video id={'video_block'} src={unique_video_url} controls autoPlay/>
                    </div>
                    <div className={'video_links'}>
                    {data2.map((k, v) => (
                    <div key={v} className={'video-container'}>
                    <Link to="#" onClick={() =>  <li key={v}>setData2('{k.Doc_Path}')</li>}>  
                    {v}
                    </Link>
                    </div>
                    ))}
           </div>
              </Modal>
              <Link to="#" id="fun" onClick={() => setFunModal(true)}>
                <div className={'link'}/>
              </Link>
              <Modal
                size="md"
                className={'video_modal'}
                show={show_fun_modal}
                onHide={() => console.log('closed')}
                backdrop="static">
                <div className={'close_button'} onClick={() => setFunModal(false)}>
                </div>
                 <div  className={'video_wrap'}>
                    <video id={'video_block'} src={fun_video_url} controls autoPlay/>
                    </div>
                    <div className={'video_links'}>
                    {data3.map((k, v) => (
                    <div key={v.toString()} className={'video-container'}>
                    <Link to="#" onClick={() => setData3('{k.Doc_Path}')}>  
                    {k.Name} 
                    </Link>
                    </div>
                    ))}
                    </div>
              </Modal>
            </div>
          </section>
        </Container>
      </section>
    </main>
  )
}

export default EthosCulture
