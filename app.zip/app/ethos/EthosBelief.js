import React, {useEffect,useState} from 'react'
import ethos from '../../assets/ethos.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/ethos_artwork.svg"
import {Col, Container, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import service from "../service/service.js";
function EthosBelief() {
  const [fetching, setFetching] = useState(false)
  const [data, setData] = useState([])
  const breadcrumb_data = [
    {
      'link': '/',
      'name': 'Home'
    },
    {
      'link': '/ethos/',
      'name': 'Our Ethos'
    },
    {
      'link': '/ethos/belief-philosophy/',
      'name': 'Belief & Philosophy'
    }
  ]

  const [belief_list, setBeliefList] = useState([
    {
      'heading': "Commit to\n customer's success;",
      'subheading': "they will grow with you"
    },
    {
      'heading': "Challenge the norm;",
      'subheading': "value will follow"
    },
    {
      'heading': "Stay focused,\n do not dilute;",
      'subheading': "they will grow with you"
    },
    {
      'heading': "Commit to\n customer's success;",
      'subheading': "will yield in multiples"
    },
    {
      'heading': "Invest in people and\n their growth;",
      'subheading': "will yield in multiples"
    },
    {
      'heading': "Avoid debt;",
      'subheading': "will yield in multiples"
    },
    {
      'heading': "Take risks, backed\n by ownership;",
      'subheading': "unless it may sink the company"
    }
  ])
const fetch_learning_data = () => {
     var results=[];
     service.getethosbeliefdetails()
     .then(res => {
        results=res.data;
         console.log("dsfa",results);    
    setFetching(true)
    setData(results)
    setTimeout(() => {
      setFetching(false)
    }, 1000)
 })
     
  }

  useEffect(() => {
    fetch_learning_data()
  }, [])
  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#D3DF4D"
                  icon_url={ethos}
                  title="Our Ethos"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'ethos artwork'}>
        <Container>
          <section id={'ethos-links'}>
            <div className={'d-flex'}>
              <Link to='/ethos/belief-philosophy/' id="ethos-belief">
                <div className={'link active'}/>
              </Link>
              <Link to='/ethos/values/' id="ethos-values">
                <div className={'link'}/>
              </Link>
              <Link to='/ethos/culture/' id="ethos-culture">
                <div className={'link'}/>
              </Link>
            </div>
          </section>
          <section id={'ethos-container'}>
            <Row>
              <Col xs={{order: 2, span: 12}} sm={{order: 1, span: 5}}>
                {belief_list.map((k, v) => (
                  <div key={v.toString()} className={'belief-item'}>
                    <p className={'title'}>{k.heading}</p>
                    <p>{k.subheading}</p>
                  </div>
                ))}
              </Col>
              <Col sm={{order: 2, span: 7}} xs={{order: 1, span: 12}} className={'video-wrap'}>
                <div className={'d-flex align-items-center justify-content-center'}>
                  <div className={'dotted-line'}/>
                  
                  {data.map((k, v) => (
                    <div  key={v.toString()} className={'video-container'}>
                    <video id={'video_block'} src={k.Doc_Path} controls autoPlay/>
                                      </div>

                    ))}
                </div>
              </Col>
            </Row>
          </section>
        </Container>
      </section>
    </main>
  )
}

export default EthosBelief
