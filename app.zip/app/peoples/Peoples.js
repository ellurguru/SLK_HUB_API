import React from 'react'
import people from '../../assets/people.png';
import BreadCrumb from "../../components/BreadCrumb";
import {ReactComponent as BreadcrumbArtwork} from "../../assets/people-artwork.svg"
import {Container} from "react-bootstrap";
import {Link} from "react-router-dom";


function College() {
  const breadcrumb_data = [
    {
      'link': '/',
      'name': 'Home'
    },
    {
      'link': '/people/',
      'name': 'Our People'
    }
  ]

  return (
    <main className={'has_footer_artwork'}>
      <BreadCrumb color="#01C6D9"
                  icon_url={people}
                  title="Our People"
                  breadcrumb_data={breadcrumb_data}
                  Artwork={BreadcrumbArtwork}/>
      <section className={'peoples'}>
        <Container>
          <section id={'paragraph'}>
            <p>
              There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration
              in
              some form, by injected humour, or randomised words which don't look even slightly believable. If you are
              going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
              middle of text.
            </p>
          </section>
          <section id={'people-container'} className={'artwork'}>
            <div id="peoples">
              <Link to="/people/college/" id="college">
                <div className={'link'}/>
              </Link>
              <Link to="/people/externalexperience/" id="external">
                <div className={'link'}/>
              </Link>
              <Link to="/people/careergrowth/" id="carrier">
                <div className={'link'}/>
              </Link>
            </div>
          </section>
        </Container>
      </section>
    </main>
  )
}

export default College
