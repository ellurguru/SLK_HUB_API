﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SLK_HUB_WEBAPI.Models
{
    public class ImpactData
    {
        public int Impact_id { get; set; }
        public string customer { get; set; }
        public string customerid { get; set; }
        public string solution { get; set; }
        public string year { get; set; }
        public string slk_champion { get; set; }
        public string slug { get; set; }
        public impactdetail detail { get; set; }
    }

    public class impactdetail
    {
        public string title { get; set; }
        public string type { get; set; }
        public string summary { get; set; }
        public List<string> keywords { get; set; }
    }
}