﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SLK_HUB_WEBAPI.Models;
namespace AdminpageWebAPI.Controllers
{
    public class SlkHubController : ApiController
    {
        private SLKHUB_DBContext db = new SLKHUB_DBContext();
        [Route("api/GetCustomers")]
        [HttpGet]
        public HttpResponseMessage GetCustomers()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                var Customers = dbContext.Customers
                                 .Select(c => new
                                 {
                                     year = c.Year_Of_Engagement,
                                     name = c.Cust_Name,
                                     image = c.Logo_Path,
                                     slug = c.Cust_Name,
                                     hover_text = c.Cust_Desc
                                 }).OrderBy(c=>c.year).ToList();
                return new HttpResponseMessage()
                {
                    Content = new StringContent(JArray.FromObject(Customers).ToString(), Encoding.UTF8, "application/json")
                };

            }
        }
        [Route("api/GetCustomersById/{id}")]
        [HttpGet]
        public HttpResponseMessage GetCustomersById(int id)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                //return dbContext.Customers.FirstOrDefault(e => e.Cust_Id == id);
                Customer customer = dbContext.Customers.Find(id);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(JArray.FromObject(dbContext.Customers.Where(cd => cd.Cust_Id == id).ToList()).ToString(), Encoding.UTF8, "application/json")
                };
            }
        }
        [Route("api/PostCustomer")]
        [ResponseType(typeof(Customer))]
        public IHttpActionResult PostEmployee(Customer cust)
        {
            if (cust is null)
            {
                return BadRequest(ModelState);
            }
            else
            {
                db.Customers.Add(cust);
                db.SaveChanges();
                return Ok(cust);
            }
        }
        [Route("api/DeleteCustomer")]
        [ResponseType(typeof(Customer))]
        public IHttpActionResult DeleteCustomer(long id)
        {
            Customer cust = db.Customers.Find(id);
            if (cust == null)
            {
                return NotFound();
            }
            db.Customers.Remove(cust);
            db.SaveChanges();
            return Ok(cust);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        [Route("api/GetCustomersProjects")]
        [HttpGet]
        public IEnumerable<Customer_Projects> GetCustomersProjects()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Customer_Projects.ToList();
            }
        }
        [Route("api/GetCustomersJourney")]
        [HttpGet]
        public IEnumerable<Customer_Journey> GetCustomersJourney()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Customer_Journey.ToList();
            }
        }
        [Route("api/GetCustomersProjectTeam")]
        [HttpGet]
        public IEnumerable<Customer_Project_Team> GetCustomersProjectTeam()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Customer_Project_Team.ToList();
            }
        }
        [Route("api/GetEmployeeJourneyPath")]
        [HttpGet]
        public IEnumerable<Employee_Journey_Path> GetEmployeeJourneyPath()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Employee_Journey_Path.ToList();
            }
        }
        [Route("api/Impacts")]
        [HttpGet]
        public IEnumerable<Impact> Impacts()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Impacts.ToList();
            }
        }

        [Route("api/CustomerDocuments/{cust_id}")]
        [HttpGet]
        public IEnumerable<Customer_Documents> CustomerDocuments(int cust_id)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Customer_Documents.Where(cd => cd.Cust_Id == cust_id).ToList();
            }
        }

        [Route("api/GetCustomerDocumentsByProject/{Proj_Name}")]
        [HttpGet]
        public IEnumerable<Customer_Documents> GetCustomerDocumentsByProject(string Proj_Name)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Customer_Documents.Where(cd => cd.Cust_Proj_Name == Proj_Name).ToList();
            }
        }

        //[Route("api/GetCustomerDocumentsByCustJourney/{Cust_Journey_Name}")]
        //[HttpGet]
        //public IEnumerable<Customer_Documents> GetCustomerDocumentsByCustJourney(string Cust_Journey_Name)
        //{
        //    using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
        //    {
        //        return dbContext.Customer_Documents.Where(cd => cd.Cust_Journey_Name == Cust_Journey_Name).ToList();
        //    }
        //}

        [Route("api/GetEthosDocumentsLevel1/{Item_Level1}")]
        [HttpGet]
        public HttpResponseMessage GetEthosDocumentsLevel1(string Item_Level1)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                // return dbContext.Customer_Documents.Where(cd => cd.Ethos_Item_Level_1 == Item_Level1).ToList();
                var json = new JavaScriptSerializer().Serialize(dbContext.Customer_Documents.Where(cd => cd.Ethos_Item_Level_1 == Item_Level1).ToList());
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetEthosDocumentsLevel2/{Item_Level2}")]
        [HttpGet]
        public HttpResponseMessage GetEthosDocumentsLevel2(string Item_Level2)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                //return dbContext.Customer_Documents.Where(cd => cd.Ethos_Item_Level_2 == Item_Level2).ToList();
                var json = new JavaScriptSerializer().Serialize(dbContext.Customer_Documents.Where(cd => cd.Ethos_Item_Level_2 == Item_Level2).ToList());
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetEmployeeJourneyPath/{Employee_Id}")]
        [HttpGet]
        public IEnumerable<Customer_Documents> GetEmployeeJourneyPath(string Employee_Id)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Customer_Documents.Where(cd => cd.Employee_Id == Employee_Id).ToList();
            }
        }

        [Route("api/GetEvolutionDocuments")]
        [HttpGet]
        public HttpResponseMessage GetEvolutionDocuments()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                //return dbContext.Evolution_Offices_Documents.ToList();
                var json = new JavaScriptSerializer().Serialize(dbContext.Evolution_Offices_Documents.ToList());
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetEvolutionStrategicFocus")]
        [HttpGet]
        public HttpResponseMessage GetEvolutionStrategicFocus()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                //return dbContext.Evolution_Strategic_Focus.ToList();
                var json = new JavaScriptSerializer().Serialize(dbContext.Evolution_Strategic_Focus.ToList());
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetLearnings")]
        [HttpGet]
        public HttpResponseMessage GetLearnings()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
               // return dbContext.Learnings.ToList();

                var json = new JavaScriptSerializer().Serialize(dbContext.Learnings.ToList());
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetCategories")]
        [HttpGet]
        public IEnumerable<Category> GetCategories()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Categories.ToList();
            }
        }

        [Route("api/GetSubcategories/{Category_Id}")]
        [HttpGet]
        public IEnumerable<Subcategory> GetSubcategories(int Category_Id)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Subcategories.Where(s => s.Category_Id == Category_Id).ToList();
            }
        }

        [Route("api/GetStotefile")]
        [HttpGet]
        public IEnumerable<Stotefile> GetStotefile()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return dbContext.Stotefiles.ToList();
            }
        }

        [Route("api/GetCustomersById1/{id}")]
        [HttpGet]
        public HttpResponseMessage GetCustomersById1(int id)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                //return dbContext.Customers.FirstOrDefault(e => e.Cust_Id == id);
                Customer customer = dbContext.Customers.Find(id);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(JArray.FromObject(dbContext.Customers.Where(cd => cd.Cust_Id == id).ToList()).ToString(), Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetCustomersData/{customername}")]
        [HttpGet]
        public HttpResponseMessage GetCustomersData(string customername)
            {

            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                Customer Customers = dbContext.Customers.Where(cd => cd.Cust_Name == customername).FirstOrDefault();
                if (Customers != null)
                {
                    CustomerModule objcust = new CustomerModule();

                    var documents = dbContext.Customer_Documents.Where(cd => cd.Cust_Id == Customers.Cust_Id)
                                    .Select(c => new docs
                                    {
                                        video = c.Doc_Path,
                                        title = c.Doc_Name,
                                        tag = c.Doc_Tags,
                                    });
                    objcust.docs = documents.ToList();

                    List<values> objvalue = new List<values>();
                    var value = dbContext.Customer_Journey.Where(cd => cd.Cust_Id == Customers.Cust_Id)
                                   .Select(v => new values
                                   {
                                       Journey_Id = v.Journey_Id,
                                       year = v.Journey_Year.ToString(),
                                       value = v.Journey_Module,
                                       about = v.Journey_Desc
                                   });

                    foreach (var p in value)
                    {
                        values obj = new values();
                        obj.Journey_Id = p.Journey_Id;
                        obj.year = p.year;
                        obj.value = p.value;
                        obj.about = p.about;
                        obj.video_link = dbContext.Customer_Documents.Where(cd => cd.Cust_Journey_ID == p.Journey_Id && cd.Doc_Tags == "video").SingleOrDefault()?.Doc_Path;
                        obj.video_description = dbContext.Customer_Documents.Where(cd => cd.Cust_Journey_ID == p.Journey_Id && cd.Doc_Tags == "video").SingleOrDefault()?.Doc_Name;
                        obj.casestudy_link = dbContext.Customer_Documents.Where(cd => cd.Cust_Journey_ID == p.Journey_Id && cd.Doc_Tags == "Document").SingleOrDefault()?.Doc_Path;
                        obj.casestudy_name = dbContext.Customer_Documents.Where(cd => cd.Cust_Journey_ID == p.Journey_Id && cd.Doc_Tags == "Document").SingleOrDefault()?.Doc_Name;

                        objvalue.Add(obj);
                    }
                    objcust.values = objvalue;

                    var slk_team = dbContext.Customer_Project_Team.Where(cp=> cp.CustomerId==Customers.Cust_Id && cp.IsClient==false)
                                   .Select(c => new slk_team
                                   {
                                       name = c.Name,
                                       designation = c.Designation,
                                       email = c.Email_Id,
                                       contact = c.Phone.ToString(),
                                       avatar = c.ProfilePic,
                                   });
                    objcust.slk_team = slk_team.ToList();

                    var client_team = dbContext.Customer_Project_Team.Where(cp => cp.CustomerId == Customers.Cust_Id && cp.IsClient == true)
                                   .Select(c => new client_team
                                   {
                                       name = c.Name,
                                       designation = c.Designation,
                                       email = c.Email_Id,
                                       contact = c.Phone,
                                       avatar = c.ProfilePic,
                                   });
                    objcust.client_team = client_team.ToList();

                    List<external_links> Objlinks = new List<external_links>();
                    external_links Objlink = new external_links();
                    Objlink.text = Customers.Cust_Name;
                    Objlink.url = Customers.Website_Link;
                    Objlinks.Add(Objlink);

                    Objlink = new external_links();
                    Objlink.text = "Leadership Team";
                    Objlink.url = Customers.Leadership_Team_Link;
                    Objlinks.Add(Objlink);

                    Objlink = new external_links();
                    Objlink.text = "Products & Services";
                    Objlink.url = Customers.Products_Link;
                    Objlinks.Add(Objlink);

                    Objlink = new external_links();
                    Objlink.text = "Financials";
                    Objlink.url = Customers.Financials_Link;
                    Objlinks.Add(Objlink);

                    objcust.external_links = Objlinks;

                    //detail objdetail = new detail();
                    //objdetail.title = "Case Study: Inflation Model";
                    //objdetail.type = "Type: New Solution/Application Key Words:";
                    //objdetail.summary = "";
                    //string[] str1;
                    //str1 = new string[] { "Procurement", "Forecast", "Data Analysis", "Reports", "Under Estimation" };
                    //objdetail.keywords = str1;

                    objcust.customer = Customers.Logo_Path;
                    //objcust.solution = "Inflation Model";
                    //objcust.year = "2001";
                    //objcust.slk_champion = "Nagesh KP";
                    objcust.slug = Customers.Cust_Name;
                    objcust.title = Customers.Cust_Name;
                    //objcust.detail = objdetail;
                    objcust.timeline = dbContext.Customer_Timeline.Where(ct => ct.CustomerId == Customers.Cust_Id)
                        .AsEnumerable().Select(v => v.Timeline).ToList();
                    //d.Keywords.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    //objcust.timeline = new string[] { "Customer since - 1998", "Industry - Automation-Solutions", "Projects 1 - Automation Engineering", "Projects 2 Industrial Wireless Technology", "Award - Operational Excellence" };
                    var json = new JavaScriptSerializer().Serialize(objcust);
                    return new HttpResponseMessage()
                    {
                        Content = new StringContent(json, Encoding.UTF8, "application/json")
                    };
                }
                else
                {
                    var message = string.Format("Customer with name = {0} not found", customername);
                    HttpError err = new HttpError(message);
                    return Request.CreateResponse(HttpStatusCode.NotFound, err);
                }
            }
        }

        [Route("api/GetEmployeeJourney")]
        [HttpGet]
        public HttpResponseMessage GetEmployeeJourney()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                List<EmployeeJourney> objourney = new List<EmployeeJourney>();
                var journey = (from ej in dbContext.Employee_Journey_Path
                               join cd in dbContext.Customer_Documents on ej.Employee_Id equals cd.Employee_Id
                               select new EmployeeJourney
                               {
                                   empid = ej.Employee_Id,
                                   name = ej.Employee_Name,
                                   image = ej.Image,
                                   video_link = cd.Doc_Path,
                                   video_description = cd.Doc_Name
                               }).Distinct().ToList();

                foreach (var p in journey)
                {
                    EmployeeJourney obj = new EmployeeJourney();
                    obj.empid = p.empid;
                    obj.name = p.name;
                    obj.image = p.image;
                    obj.video_link = p.video_link;
                    obj.video_description = p.video_description;
                    obj.records = dbContext.Employee_Journey_Path.Where(j => j.Employee_Id == p.empid)
                    .Select(d => new records
                    {
                        highlight = d.Highlight,
                        star = d.Star,
                        title = d.Title,
                        year = d.JourneyYear
                    }).ToList();

                    objourney.Add(obj);

                }

                var json = new JavaScriptSerializer().Serialize(objourney);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetExternalExperience")]
        [HttpGet]
        public HttpResponseMessage GetExternalExperience()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                List<ExternalExperience> objexternal = new List<ExternalExperience>();
                var journey = (from ej in dbContext.Employee_External_Experience
                               join cd in dbContext.Customer_Documents on ej.Employee_Id equals cd.Employee_Id
                               select new ExternalExperience
                               {
                                   empid = ej.Employee_Id,
                                   name = ej.Employee_Name,
                                   image = ej.Image,
                                   video_link = cd.Doc_Path,
                                   video_description = cd.Doc_Name
                               }).Distinct().ToList();

                foreach (var p in journey)
                {
                    ExternalExperience obj = new ExternalExperience();
                    obj.empid = p.empid;
                    obj.name = p.name;
                    obj.image = p.image;
                    obj.video_link = p.video_link;
                    obj.video_description = p.video_description;
                    obj.records = dbContext.Employee_External_Experience.Where(j => j.Employee_Id == p.empid)
                    .Select(d => new externalrecords
                    {
                        highlight = d.Highlight,
                        star = d.Star,
                        title = d.Title,
                        year = d.JourneyYear
                    }).ToList();

                    objexternal.Add(obj);

                }

                var json = new JavaScriptSerializer().Serialize(objexternal);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetCareerGrowth")]
        [HttpGet]
        public HttpResponseMessage GetGetCareerGrowth()
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                List<CareerGrowth> objcareer = new List<CareerGrowth>();
                var journey = (from ej in dbContext.Employee_Career_Growth
                               join cd in dbContext.Customer_Documents on ej.Employee_Id equals cd.Employee_Id
                               select new EmployeeJourney
                               {
                                   empid = ej.Employee_Id,
                                   name = ej.Employee_Name,
                                   image = ej.Image,
                                   video_link = cd.Doc_Path,
                                   video_description = cd.Doc_Name
                               }).Distinct().ToList();

                foreach (var p in journey)
                {
                    CareerGrowth obj = new CareerGrowth();
                    obj.empid = p.empid;
                    obj.name = p.name;
                    obj.image = p.image;
                    obj.video_link = p.video_link;
                    obj.video_description = p.video_description;
                    obj.records = dbContext.Employee_Career_Growth.Where(j => j.Employee_Id == p.empid)
                    .Select(d => new careergrowthrecords
                    {
                        highlight = d.Highlight,
                        star = d.Star,
                        title = d.Title,
                        year = d.JourneyYear
                    }).ToList();

                    objcareer.Add(obj);

                }

                var json = new JavaScriptSerializer().Serialize(objcareer);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetImpactData/{ImpactType}")]
        [HttpGet]
        public HttpResponseMessage GetImpactData(string ImpactType)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                List<ImpactData> objimpact = new List<ImpactData>();

                var impact = ImpactType == "All" ? (from i in dbContext.Impacts
                                                    select new ImpactData
                                                    {
                                                        Impact_id = i.Impact_id,
                                                        customer = i.CustomerLogo,
                                                        solution = i.Solution,
                                                        year = i.Impact_Year,
                                                        slk_champion = i.SLK_Champion,
                                                        customerid = i.CustomerId
                                                    }).Distinct().ToList()
                               : (from i in dbContext.Impacts.Where(j => j.ImpactType == ImpactType)
                                  select new ImpactData
                                  {
                                      Impact_id = i.Impact_id,
                                      customer = i.CustomerLogo,
                                      solution = i.Solution,
                                      year = i.Impact_Year,
                                      slk_champion = i.SLK_Champion,
                                      customerid = i.CustomerId
                                  }).Distinct().ToList();

                foreach (var p in impact)
                {
                    ImpactData obj = new ImpactData();
                    obj.Impact_id = p.Impact_id;
                    obj.customer = p.customer;
                    obj.solution = p.solution;
                    obj.year = p.year;
                    obj.slk_champion = p.slk_champion;
                    obj.customerid = p.customerid;
                    int customerid = Convert.ToInt32(p.customerid);
                    obj.slug = dbContext.Customers.Where(x => x.Cust_Id == customerid).SingleOrDefault()?.Cust_Name;
                    obj.detail = dbContext.Impacts.Where(j => j.Impact_id == p.Impact_id)
                    .AsEnumerable()
                    .Select(d => new impactdetail
                    {
                        title = d.Title,
                        type = d.Type,
                        summary = "",
                        keywords = d.Keywords.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList()

                    }).FirstOrDefault();
                    objimpact.Add(obj);
                }

                var json = new JavaScriptSerializer().Serialize(objimpact);
                Console.WriteLine(json);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetImpactDetailsById/{cust_id}/{impact_id}")]
        [HttpGet]
        public HttpResponseMessage GetImpactDetailsById(int cust_id,int impact_id)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                ImpactModule objcust = new ImpactModule();
                Customer Customers = dbContext.Customers.Where(cd => cd.Cust_Id == cust_id).FirstOrDefault();
                Impact impacts = dbContext.Impacts.Where(i => i.Impact_id == impact_id).FirstOrDefault();
                var documents = dbContext.Customer_Documents.Where(cd => cd.Cust_Id == cust_id)
                                .Select(c => new impdocs
                                {
                                    video = c.Doc_Path,
                                    title = c.Doc_Name,
                                    tag = c.Doc_Tags,
                                });
                objcust.docs = documents.ToList();

                impdetail objdetail = new impdetail();
                objdetail.title = impacts.Title;
                objdetail.type = impacts.Type;
                objdetail.summary = "";
                objdetail.keywords = impacts.Keywords.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                objcust.detail = objdetail;

                objcust.solution = impacts.Solution;
                objcust.year = impacts.Impact_Year;
                objcust.slk_champion = impacts.SLK_Champion;
                objcust.slug = Customers.Cust_Name;
                objcust.title = Customers.Cust_Name;
                objcust.customer = impacts.CustomerLogo;

                //objcust.timeline = new string[] { "Customer since - 1998", "Industry - Automation-Solutions", "Projects 1 - Automation Engineering", "Projects 2 Industrial Wireless Technology", "Award - Operational Excellence" };
                objcust.timeline = dbContext.Customer_Timeline.Where(ct => ct.CustomerId == Customers.Cust_Id)
                        .AsEnumerable().Select(v => v.Timeline).ToList();
                var json = new JavaScriptSerializer().Serialize(objcust);
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
        }

        [Route("api/GetEthosCulture_Innovation/{Innovation}")]
        [HttpGet]
        public HttpResponseMessage GetEthosCulture_Innovation(string Innovation)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(JArray.FromObject(dbContext.Ethos_Culture.Where(cd => cd.Culture_Type == Innovation).ToList()).ToString(), Encoding.UTF8, "application/json")
                };
            }
        }
        [Route("api/GetEthosCulture_Unique/{Unique}")]
        [HttpGet]
        public HttpResponseMessage GetEthosCulture_Unique(string Unique)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(JArray.FromObject(dbContext.Ethos_Culture.Where(cd => cd.Culture_Type == Unique).ToList()).ToString(), Encoding.UTF8, "application/json")
                };
            }
        }
        [Route("api/GetEthosCulture_Fun/{Fun}")]
        [HttpGet]
        public HttpResponseMessage GetEthosCulture_Fun(string Fun)
        {
            using (SLKHUB_DBContext dbContext = new SLKHUB_DBContext())
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(JArray.FromObject(dbContext.Ethos_Culture.Where(cd => cd.Culture_Type == Fun).ToList()).ToString(), Encoding.UTF8, "application/json")
                };
            }
        }

    }
}
