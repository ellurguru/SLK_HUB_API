﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SLK_HUB_WEBAPI.Models
{
    public class SendMailRequest
    {
        public string uploadby { get; set; }
        public string uploadedon { get; set; }
        public string videoname { get; set; }
        public string category { get; set; }
        public string templateid { get; set; }
        public string filecontent { get; set; }
        public string filename { get; set; }
    }
}